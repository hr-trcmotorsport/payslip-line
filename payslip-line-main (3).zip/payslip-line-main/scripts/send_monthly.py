"""รันโดย GitHub Actions: ส่งสลิปอัตโนมัติ "วันสิ้นเดือน" (ตามเวลาไทย)"""
import argparse
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from common import db, sender  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--period", help="YYYY-MM (ค่าเริ่มต้น = เดือนปัจจุบัน)")
    ap.add_argument("--force", action="store_true", help="ส่งแม้ไม่ใช่วันสิ้นเดือน")
    args = ap.parse_args()

    today = datetime.now(db.TZ).date()
    if not args.force and (today + timedelta(days=1)).day != 1:
        print(f"{today} ไม่ใช่วันสิ้นเดือน ข้าม")
        return 0

    period = args.period or today.strftime("%Y-%m")
    if not db.list_payslips(period):
        print(f"::error::ยังไม่มีสลิปงวด {period} ในระบบ (HR ลืมอัปโหลดหรือเปล่า?)")
        return 1

    res = sender.send_period(period)
    print(f"งวด {period}: ส่งสำเร็จ {len(res['sent'])} คน")
    for key, label in [
        ("failed", "ส่งไม่สำเร็จ"),
        ("skipped_quota", "ข้ามเพราะโควต้าเต็ม"),
        ("slip_but_not_registered", "มีสลิปแต่ยังไม่ผูกไลน์"),
        ("registered_but_no_slip", "ผูกไลน์แล้วแต่ไม่มีสลิป"),
    ]:
        if res[key]:
            print(f"{label} {len(res[key])}: {res[key]}")
    return 1 if res["failed"] or res["skipped_quota"] else 0


if __name__ == "__main__":
    sys.exit(main())
