import io
import os
import re
import secrets

from pypdf import PdfReader, PdfWriter

from .config import get
from .security import normalize_code


def _regex() -> re.Pattern:
    # ปรับให้ตรงกับรูปแบบรหัสพนักงานของบริษัทได้ผ่าน EMP_CODE_REGEX
    return re.compile(get("EMP_CODE_REGEX", r"[A-Za-z]{0,3}\d{3,8}"))


def extract_code(filename: str, data: bytes) -> str:
    """หารหัสพนักงานจากชื่อไฟล์ ถ้าไม่เจอค่อยหาในข้อความหน้าแรกของ PDF"""
    rx = _regex()
    stem = os.path.splitext(os.path.basename(filename))[0]
    if rx.fullmatch(stem):
        return normalize_code(stem)
    found = rx.findall(stem)
    if found:
        return normalize_code(found[-1])
    try:
        text = PdfReader(io.BytesIO(data)).pages[0].extract_text() or ""
        m = rx.search(text)
        if m:
            return normalize_code(m.group(0))
    except Exception:
        pass
    return ""


def encrypt_pdf(data: bytes, password: str) -> bytes:
    reader = PdfReader(io.BytesIO(data))
    if reader.is_encrypted:
        raise ValueError("ไฟล์ต้นฉบับมีรหัสผ่านอยู่แล้ว")
    writer = PdfWriter()
    for page in reader.pages:
        writer.add_page(page)
    writer.encrypt(
        user_password=password,
        owner_password=secrets.token_hex(8),
        algorithm="AES-128",
    )
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()
