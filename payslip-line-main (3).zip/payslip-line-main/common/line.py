import base64
import hashlib
import hmac

import requests

from . import db
from .config import require

API = "https://api.line.me/v2/bot/message"


def verify_signature(body: bytes, signature: str) -> bool:
    secret = require("LINE_CHANNEL_SECRET").encode()
    digest = hmac.new(secret, body, hashlib.sha256).digest()
    return hmac.compare_digest(base64.b64encode(digest).decode(), signature or "")


def _post(path: str, payload: dict):
    r = requests.post(
        f"{API}/{path}",
        headers={"Authorization": f"Bearer {require('LINE_CHANNEL_ACCESS_TOKEN')}"},
        json=payload,
        timeout=15,
    )
    if r.status_code != 200:
        raise RuntimeError(f"LINE {path} {r.status_code}: {r.text[:200]}")


def reply(reply_token: str, text: str):
    """ตอบกลับตอนที่พนักงานทักมา — ไม่นับโควต้า push"""
    _post("reply", {"replyToken": reply_token, "messages": [{"type": "text", "text": text}]})


def push(user_id: str, text: str, kind: str = "payslip"):
    """ส่งหาพนักงานเอง — นับโควต้ารายเดือน"""
    _post("push", {"to": user_id, "messages": [{"type": "text", "text": text}]})
    db.log_push(kind, user_id)
