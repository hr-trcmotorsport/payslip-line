import io

from pypdf import PdfReader

from . import db, line
from .config import get, link_expire_days, monthly_limit

TH_MONTHS = ["มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
             "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"]


def period_th(period: str) -> str:
    y, m = period.split("-")
    return f"{TH_MONTHS[int(m) - 1]} {int(y) + 543}"


def build_text(period: str, url: str) -> str:
    # ไฟล์ต้นฉบับมีรหัสผ่านอยู่แล้ว (พนักงานรู้รหัสเดิม) ปรับคำอธิบายได้ด้วย PASSWORD_HINT
    hint = get("PASSWORD_HINT", "วันเกิดของคุณ")
    return (
        f"สลิปเงินเดือน {period_th(period)}\n"
        f"กดเปิดไฟล์: {url}\n\n"
        f"รหัสเปิดไฟล์ = {hint}\n"
        f"(ลิงก์ใช้ได้ {link_expire_days()} วัน หมดอายุแล้วพิมพ์ \"สลิป\" เพื่อขอลิงก์ใหม่)"
    )


def get_link(emp: dict, period: str, raw_path: str) -> str:
    """ไฟล์ต้นฉบับมีรหัสผ่านอยู่แล้ว → ทำลิงก์ชั่วคราวไปที่ไฟล์นั้นตรงๆ

    ถ้าพบไฟล์ที่ไม่มีรหัสผ่าน จะไม่ส่ง (กันสลิปหลุดแบบเปิดได้เลย) ให้แจ้ง HR ตรวจไฟล์
    """
    raw = db.download(raw_path)
    if not PdfReader(io.BytesIO(raw)).is_encrypted:
        raise ValueError("ไฟล์สลิปนี้ไม่มีรหัสผ่าน จึงไม่ส่งเพื่อความปลอดภัย (ตรวจไฟล์ต้นฉบับ)")
    return db.signed_url(raw_path, link_expire_days() * 86400)


def send_period(period: str, only_codes: set[str] | None = None) -> dict:
    emps = {e["emp_code"]: e for e in db.list_employees() if e.get("active")}
    slips = db.list_payslips(period)
    done = db.sent_ok(period)
    todo = [c for c in slips if c in emps and c not in done and (only_codes is None or c in only_codes)]

    remaining = monthly_limit() - db.push_count_this_month()
    res = {
        "sent": [],
        "failed": [],
        "skipped_quota": [],
        "slip_but_not_registered": [c for c in slips if c not in emps],
        "registered_but_no_slip": [c for c in emps if c not in slips],
        "quota_remaining_before": remaining,
    }
    for c in todo:
        if len(res["sent"]) >= remaining:
            res["skipped_quota"].append(c)
            continue
        try:
            url = get_link(emps[c], period, slips[c])
            line.push(emps[c]["line_user_id"], build_text(period, url))
            db.log_send(period, c, "ok", None)
            res["sent"].append(c)
        except Exception as e:  # noqa: BLE001 - อยากให้คนอื่นส่งต่อได้แม้คนนี้พัง
            msg = str(e)[:300]
            db.log_send(period, c, "error", msg)
            res["failed"].append((c, msg))
    return res
