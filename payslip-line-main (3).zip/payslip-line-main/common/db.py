"""ชั้นเข้าถึง Supabase (Postgres + Storage)"""
from datetime import datetime
from functools import lru_cache
from zoneinfo import ZoneInfo

from .config import require
from .security import decrypt, encrypt, hash_id, pdf_password

TZ = ZoneInfo("Asia/Bangkok")
BUCKET = "payslips"


@lru_cache(maxsize=1)
def client():
    from supabase import create_client

    return create_client(require("SUPABASE_URL"), require("SUPABASE_SERVICE_KEY"))


def T(name: str):
    return client().table(name)


def now_iso() -> str:
    return datetime.now(TZ).isoformat()


# ---------- ลงทะเบียน ----------
def add_registration(line_user_id: str, emp_code: str, national_id: str, display_name: str = ""):
    T("registrations").delete().eq("line_user_id", line_user_id).eq("status", "pending").execute()
    T("registrations").insert(
        {
            "line_user_id": line_user_id,
            "emp_code": emp_code,
            "national_id_enc": encrypt(national_id),
            "display_name": display_name,
            "status": "pending",
        }
    ).execute()


def pending_registrations() -> list[dict]:
    return T("registrations").select("*").eq("status", "pending").order("created_at").execute().data


def has_pending(line_user_id: str) -> bool:
    r = T("registrations").select("id").eq("line_user_id", line_user_id).eq("status", "pending").execute()
    return bool(r.data)


def approve_registration(reg_id: int) -> dict:
    reg = T("registrations").select("*").eq("id", reg_id).single().execute().data
    nid = decrypt(reg["national_id_enc"])
    code, uid = reg["emp_code"], reg["line_user_id"]
    # ไลน์นี้เคยผูกกับรหัสอื่น → ย้ายมารหัสใหม่
    T("employees").delete().eq("line_user_id", uid).neq("emp_code", code).execute()
    row = {
        "emp_code": code,
        "line_user_id": uid,
        "national_id_hash": hash_id(nid),
        "pdf_password_enc": encrypt(pdf_password(nid)),
        "active": True,
        "registered_at": now_iso(),
    }
    T("employees").upsert(row, on_conflict="emp_code").execute()
    T("registrations").update({"status": "approved", "national_id_enc": None}).eq("id", reg_id).execute()
    return row


def reject_registration(reg_id: int):
    T("registrations").update({"status": "rejected", "national_id_enc": None}).eq("id", reg_id).execute()


# ---------- พนักงาน ----------
def get_employee_by_line(line_user_id: str) -> dict | None:
    r = T("employees").select("*").eq("line_user_id", line_user_id).eq("active", True).execute().data
    return r[0] if r else None


def get_employee_by_code(code: str) -> dict | None:
    r = T("employees").select("*").eq("emp_code", code).execute().data
    return r[0] if r else None


def list_employees() -> list[dict]:
    return T("employees").select("*").order("emp_code").execute().data


def unlink_employee(code: str):
    T("employees").delete().eq("emp_code", code).execute()


# ---------- สลิป ----------
def storage():
    return client().storage.from_(BUCKET)


def save_payslip(period: str, code: str, data: bytes):
    path = f"raw/{period}/{code}.pdf"
    storage().upload(path, data, {"content-type": "application/pdf", "upsert": "true"})
    T("payslips").upsert(
        {"period": period, "emp_code": code, "raw_path": path, "uploaded_at": now_iso()},
        on_conflict="period,emp_code",
    ).execute()


def list_payslips(period: str) -> dict[str, str]:
    rows = T("payslips").select("emp_code,raw_path").eq("period", period).execute().data
    return {r["emp_code"]: r["raw_path"] for r in rows}


def latest_payslip(code: str, period: str | None = None) -> tuple[str, str] | None:
    q = T("payslips").select("period,raw_path").eq("emp_code", code)
    if period:
        q = q.eq("period", period)
    rows = q.order("period", desc=True).limit(1).execute().data
    return (rows[0]["period"], rows[0]["raw_path"]) if rows else None


def download(path: str) -> bytes:
    return storage().download(path)


def upload_enc(period: str, code: str, data: bytes) -> str:
    path = f"enc/{period}/{code}.pdf"
    storage().upload(path, data, {"content-type": "application/pdf", "upsert": "true"})
    return path


def signed_url(path: str, expires_sec: int) -> str:
    res = storage().create_signed_url(path, expires_sec)
    url = res.get("signedURL") or res.get("signedUrl")
    if url.startswith("/"):
        url = require("SUPABASE_URL").rstrip("/") + "/storage/v1" + url
    return url


# ---------- log การส่ง / โควต้า ----------
def sent_ok(period: str) -> set[str]:
    rows = T("send_log").select("emp_code").eq("period", period).eq("status", "ok").execute().data
    return {r["emp_code"] for r in rows}


def send_status(period: str) -> dict[str, dict]:
    rows = T("send_log").select("*").eq("period", period).execute().data
    return {r["emp_code"]: r for r in rows}


def log_send(period: str, code: str, status: str, error: str | None):
    T("send_log").upsert(
        {"period": period, "emp_code": code, "status": status, "error": error, "sent_at": now_iso()},
        on_conflict="period,emp_code",
    ).execute()


def log_push(kind: str, user_id: str):
    T("push_log").insert({"kind": kind, "line_user_id": user_id}).execute()


def push_count_this_month() -> int:
    n = datetime.now(TZ)
    start = n.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()
    r = T("push_log").select("id", count="exact").gte("ts", start).execute()
    return r.count or 0
