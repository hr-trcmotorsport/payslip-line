import hashlib
import re

from cryptography.fernet import Fernet

from .config import get, require


def _fernet() -> Fernet:
    return Fernet(require("ENCRYPTION_KEY").encode())


def encrypt(text: str) -> str:
    return _fernet().encrypt(text.encode()).decode()


def decrypt(token: str) -> str:
    return _fernet().decrypt(token.encode()).decode()


def hash_id(national_id: str) -> str:
    return hashlib.sha256((get("PEPPER", "") + national_id).encode()).hexdigest()


def valid_thai_id(nid: str) -> bool:
    """ตรวจเลขบัตรประชาชน 13 หลักด้วย checksum"""
    if not re.fullmatch(r"\d{13}", nid or ""):
        return False
    total = sum(int(nid[i]) * (13 - i) for i in range(12))
    return (11 - total % 11) % 10 == int(nid[12])


def normalize_code(code: str) -> str:
    return re.sub(r"\s+", "", code or "").upper()


def pdf_password(national_id: str) -> str:
    """รหัสเปิดไฟล์ PDF = เลขบัตร ปชช. N ตัวท้าย (ปรับได้ด้วย PDF_PASSWORD_DIGITS)"""
    n = int(get("PDF_PASSWORD_DIGITS", "4"))
    return national_id[-n:]
