"""อ่านค่า config จาก environment ก่อน แล้วค่อยลอง st.secrets (Streamlit Cloud)"""
import os


def get(name: str, default=None):
    v = os.environ.get(name)
    if v:
        return v
    try:
        import streamlit as st  # มีเฉพาะฝั่งแอดมิน

        v = st.secrets.get(name)
        if v:
            return str(v)
    except Exception:
        pass
    return default


def require(name: str) -> str:
    v = get(name)
    if not v:
        raise RuntimeError(f"ยังไม่ได้ตั้งค่า {name}")
    return v


def monthly_limit() -> int:
    return int(get("LINE_MONTHLY_LIMIT", "500"))


def link_expire_days() -> int:
    return int(get("LINK_EXPIRE_DAYS", "14"))
