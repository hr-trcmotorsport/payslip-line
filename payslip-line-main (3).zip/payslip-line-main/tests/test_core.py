import io
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("PEPPER", "test")

from pypdf import PdfReader, PdfWriter  # noqa: E402

from common import pdftools, security  # noqa: E402
from webhook.main import parse_registration  # noqa: E402


def blank_pdf() -> bytes:
    w = PdfWriter()
    w.add_blank_page(200, 200)
    b = io.BytesIO()
    w.write(b)
    return b.getvalue()


def test_thai_id():
    assert security.valid_thai_id("1101700230678")
    assert not security.valid_thai_id("1101700230679")
    assert not security.valid_thai_id("123")


def test_parse_registration():
    assert parse_registration("ลงทะเบียน e0123 1101700230678") == ("E0123", "1101700230678")
    assert parse_registration("E0123 1-1017-00230-67-8") == ("E0123", "1101700230678")
    assert parse_registration("1101700230678 E0123") == ("E0123", "1101700230678")
    assert parse_registration("สวัสดี") is None


def test_extract_code():
    d = blank_pdf()
    assert pdftools.extract_code("E0123.pdf", d) == "E0123"
    assert pdftools.extract_code("payslip_2026-09_E0123.pdf", d) == "E0123"
    assert pdftools.extract_code("abc.pdf", d) == ""


def test_encrypt_pdf():
    enc = pdftools.encrypt_pdf(blank_pdf(), "1234")
    r = PdfReader(io.BytesIO(enc))
    assert r.is_encrypted
    assert r.decrypt("1234") != 0
    assert len(r.pages) == 1


def test_fernet_roundtrip():
    from cryptography.fernet import Fernet

    os.environ["ENCRYPTION_KEY"] = Fernet.generate_key().decode()
    assert security.decrypt(security.encrypt("secret")) == "secret"
    assert security.pdf_password("1101700230678") == "0678"
