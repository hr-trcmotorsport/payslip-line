"""ตัวรับ webhook จาก LINE (FastAPI) — รันบน Render"""
import json
import logging
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, Header, HTTPException, Request  # noqa: E402

from common import db, line, sender  # noqa: E402
from common.config import link_expire_days  # noqa: E402
from common.security import normalize_code, valid_thai_id  # noqa: E402

log = logging.getLogger("payslip")
app = FastAPI()

HOWTO = (
    "สวัสดีค่ะ 👋 ระบบส่งสลิปเงินเดือนอัตโนมัติ\n\n"
    "ลงทะเบียนครั้งแรก พิมพ์แบบนี้ค่ะ\n"
    "ลงทะเบียน <รหัสพนักงาน> <เลขบัตรประชาชน 13 หลัก>\n"
    "เช่น ลงทะเบียน E0123 1234567890123\n\n"
    "แล้วรอ HR ยืนยัน หลังจากนั้นสลิปจะส่งให้ทุกสิ้นเดือนค่ะ"
)
ID_PLAIN = re.compile(r"(?<!\d)\d{13}(?!\d)")
ID_DASH = re.compile(r"(?<!\d)\d-\d{4}-\d{5}-\d{2}-\d(?!\d)")


def parse_registration(text: str) -> tuple[str, str] | None:
    """คืน (รหัสพนักงาน, เลขบัตร) หรือ None ถ้าข้อความไม่ใช่การลงทะเบียน"""
    m = ID_PLAIN.search(text) or ID_DASH.search(text)
    if not m:
        return None
    nid = m.group(0).replace("-", "")
    rest = (text[: m.start()] + " " + text[m.end():]).replace("ลงทะเบียน", " ")
    tokens = [t for t in re.split(r"[\s,;:]+", rest) if t]
    if not tokens:
        return None
    return normalize_code(tokens[0]), nid


def handle_text(uid: str, token: str, text: str):
    text = text.strip()
    emp = db.get_employee_by_line(uid)

    # พนักงานที่ผูกแล้ว: ขอสลิปย้อนหลัง/ลิงก์ใหม่ (reply = ฟรี ไม่นับโควต้า)
    if emp and re.match(r"^(สลีป|สลิป|slip|payslip)", text, re.I):
        m = re.search(r"\d{4}-\d{2}", text)
        found = db.latest_payslip(emp["emp_code"], m.group(0) if m else None)
        if not found:
            return line.reply(token, "ยังไม่พบสลิปที่ขอค่ะ ลองถามฝ่าย HR นะคะ")
        period, raw_path = found
        url = sender.get_link(emp, period, raw_path)
        return line.reply(token, sender.build_text(period, url))
    if emp:
        return line.reply(
            token,
            f"ลงทะเบียนแล้วค่ะ (รหัส {emp['emp_code']}) ✅\n"
            f"พิมพ์ \"สลิป\" เพื่อขอลิงก์สลิปล่าสุด (ลิงก์ใช้ได้ {link_expire_days()} วัน)",
        )

    reg = parse_registration(text)
    if reg:
        code, nid = reg
        if not valid_thai_id(nid):
            return line.reply(token, "เลขบัตรประชาชนไม่ถูกต้องค่ะ ลองตรวจอีกรอบนะคะ")
        db.add_registration(uid, code, nid)
        return line.reply(
            token,
            f"รับเรื่องแล้วค่ะ รหัส {code}\nรอ HR ตรวจสอบและยืนยัน เดี๋ยวแจ้งกลับนะคะ 🙏\n"
            "(แนะนำให้ลบข้อความที่มีเลขบัตรในแชทนี้ทิ้งด้วยค่ะ)",
        )
    if db.has_pending(uid):
        return line.reply(token, "เรื่องของคุณอยู่ระหว่างรอ HR ยืนยันค่ะ ⏳")
    return line.reply(token, HOWTO)


def handle(ev: dict):
    token = ev.get("replyToken")
    uid = (ev.get("source") or {}).get("userId")
    if not uid or not token:
        return
    if ev.get("type") == "follow":
        return line.reply(token, HOWTO)
    if ev.get("type") == "message" and (ev.get("message") or {}).get("type") == "text":
        return handle_text(uid, token, ev["message"]["text"])


@app.get("/health")
def health():
    return {"ok": True}


@app.post("/callback")
async def callback(request: Request, x_line_signature: str = Header(default="")):
    body = await request.body()
    if not line.verify_signature(body, x_line_signature):
        raise HTTPException(status_code=400, detail="bad signature")
    for ev in json.loads(body).get("events", []):
        try:
            handle(ev)
        except Exception:  # noqa: BLE001
            log.exception("handle event failed")
    return {"ok": True}
