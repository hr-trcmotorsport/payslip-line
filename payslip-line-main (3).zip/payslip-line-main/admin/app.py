"""หน้าแอดมินสำหรับ HR (Streamlit): ยืนยันพนักงาน / อัปโหลดสลิป / กดส่ง"""
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd  # noqa: E402
import streamlit as st  # noqa: E402

from common import db, line, pdftools, sender  # noqa: E402
from common.config import get, monthly_limit  # noqa: E402
from common.security import decrypt, normalize_code  # noqa: E402

st.set_page_config(page_title="ระบบส่งสลิปเงินเดือน", page_icon="🧾", layout="wide")

# ---------- ล็อกอินแอดมิน ----------
if not st.session_state.get("ok"):
    st.title("🧾 ระบบส่งสลิปเงินเดือน")
    pw = st.text_input("รหัสผ่านแอดมิน", type="password")
    if st.button("เข้าสู่ระบบ"):
        if pw and pw == get("ADMIN_PASSWORD"):
            st.session_state["ok"] = True
            st.rerun()
        else:
            st.error("รหัสผ่านไม่ถูกต้อง")
    st.stop()

used = db.push_count_this_month()
st.title("🧾 ระบบส่งสลิปเงินเดือน")
st.progress(min(used / monthly_limit(), 1.0), text=f"โควต้า LINE เดือนนี้ใช้ไป {used}/{monthly_limit()} ข้อความ")

tab1, tab2, tab3, tab4 = st.tabs(["✅ ยืนยันพนักงาน", "📤 อัปโหลดสลิป", "📨 ส่งสลิป", "👥 พนักงาน"])

# ---------- 1) ยืนยันพนักงาน ----------
with tab1:
    pend = db.pending_registrations()
    if not pend:
        st.info("ไม่มีรายการรอยืนยัน")
    for r in pend:
        existing = db.get_employee_by_code(r["emp_code"])
        with st.container(border=True):
            c1, c2, c3 = st.columns([4, 1, 1])
            c1.markdown(
                f"**รหัส:** `{r['emp_code']}`  \n"
                f"**เลขบัตร ปชช.:** `{decrypt(r['national_id_enc'])}`  \n"
                f"**ส่งมาเมื่อ:** {r['created_at'][:16].replace('T', ' ')}"
            )
            if existing and existing["line_user_id"] != r["line_user_id"]:
                c1.warning("รหัสนี้ผูกกับไลน์อื่นอยู่แล้ว — ถ้าอนุมัติ จะย้ายสิทธิ์มาไลน์นี้")
            if c2.button("อนุมัติ", key=f"ap{r['id']}", type="primary"):
                db.approve_registration(r["id"])
                try:
                    line.push(
                        r["line_user_id"],
                        "HR ยืนยันแล้วค่ะ ✅ ต่อไปสลิปจะส่งให้ทุกสิ้นเดือน\nพิมพ์ \"สลิป\" เพื่อขอลิงก์สลิปล่าสุดได้ตลอดค่ะ",
                        kind="approve",
                    )
                except Exception as e:  # noqa: BLE001
                    st.warning(f"อนุมัติแล้ว แต่แจ้งไลน์ไม่สำเร็จ: {e}")
                st.rerun()
            if c3.button("ปฏิเสธ", key=f"rj{r['id']}"):
                db.reject_registration(r["id"])
                st.rerun()

# ---------- 2) อัปโหลดสลิป ----------
with tab2:
    default_period = datetime.now(db.TZ).strftime("%Y-%m")
    period = st.text_input("งวด (YYYY-MM)", value=default_period, key="up_period")
    files = st.file_uploader("เลือกไฟล์ PDF สลิป (เลือกได้ทีเดียวหลายไฟล์)", type="pdf", accept_multiple_files=True)
    if files:
        rows = []
        for f in files:
            data = f.getvalue()
            rows.append({"ไฟล์": f.name, "รหัสพนักงาน": pdftools.extract_code(f.name, data)})
        st.caption("ตรวจรหัสที่อ่านได้ แก้ในตารางได้เลยถ้าผิด/ว่าง")
        edited = st.data_editor(pd.DataFrame(rows), use_container_width=True, hide_index=True, disabled=["ไฟล์"])
        codes = [normalize_code(c) for c in edited["รหัสพนักงาน"].fillna("")]
        dup = {c for c in codes if c and codes.count(c) > 1}
        if dup:
            st.error(f"รหัสซ้ำกัน: {', '.join(sorted(dup))}")
        if st.button("บันทึกสลิปเข้าระบบ", type="primary", disabled=bool(dup)):
            bar, ok, skip = st.progress(0.0), 0, []
            for i, (f, code) in enumerate(zip(files, codes)):
                if code:
                    db.save_payslip(period, code, f.getvalue())
                    ok += 1
                else:
                    skip.append(f.name)
                bar.progress((i + 1) / len(files))
            st.success(f"บันทึกแล้ว {ok} ไฟล์ (งวด {period})")
            if skip:
                st.warning("ข้ามเพราะไม่มีรหัส: " + ", ".join(skip))

# ---------- 3) ส่งสลิป ----------
with tab3:
    sp = st.text_input("งวดที่จะส่ง (YYYY-MM)", value=default_period, key="send_period")
    emps = {e["emp_code"]: e for e in db.list_employees()}
    slips = db.list_payslips(sp)
    status = db.send_status(sp)
    codes_all = sorted(set(emps) | set(slips))
    table = pd.DataFrame(
        [
            {
                "รหัส": c,
                "ผูกไลน์แล้ว": "✅" if c in emps else "—",
                "มีไฟล์สลิป": "✅" if c in slips else "—",
                "สถานะส่ง": {"ok": "ส่งแล้ว", "error": "ผิดพลาด"}.get((status.get(c) or {}).get("status"), "ยังไม่ส่ง"),
            }
            for c in codes_all
        ]
    )
    ready = [c for c in slips if c in emps and (status.get(c) or {}).get("status") != "ok"]
    m1, m2, m3 = st.columns(3)
    m1.metric("พร้อมส่ง", len(ready))
    m2.metric("มีสลิปแต่ยังไม่ผูกไลน์", len([c for c in slips if c not in emps]))
    m3.metric("ผูกไลน์แต่ไม่มีสลิป", len([c for c in emps if c not in slips]))
    st.dataframe(table, use_container_width=True, hide_index=True)

    confirm = st.checkbox(f"ยืนยันส่งสลิปงวด {sp} ให้ {len(ready)} คน")
    if st.button("📨 ส่งเลย", type="primary", disabled=not (confirm and ready)):
        with st.spinner("กำลังส่ง..."):
            res = sender.send_period(sp)
        st.success(f"ส่งสำเร็จ {len(res['sent'])} คน")
        if res["failed"]:
            st.error("ส่งไม่สำเร็จ: " + "; ".join(f"{c} ({m})" for c, m in res["failed"]))
        if res["skipped_quota"]:
            st.warning(f"โควต้าไม่พอ ข้ามไป {len(res['skipped_quota'])} คน")

# ---------- 4) พนักงาน ----------
with tab4:
    emps = db.list_employees()
    st.write(f"ลงทะเบียนแล้ว {len(emps)} คน")
    for e in emps:
        c1, c2 = st.columns([5, 1])
        c1.write(f"`{e['emp_code']}` — ลงทะเบียน {e['registered_at'][:10]}")
        if c2.button("ยกเลิกการผูก", key=f"un{e['emp_code']}"):
            db.unlink_employee(e["emp_code"])
            st.rerun()
